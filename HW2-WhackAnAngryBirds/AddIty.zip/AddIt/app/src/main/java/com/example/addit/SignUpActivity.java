package com.example.addit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.print.PrinterId;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignUpActivity extends AppCompatActivity {
    private EditText user_name;
    private EditText email;
    private EditText password;
    private EditText confirm_password;
    private Button sign_up_btn;
    private FirebaseAuth _Auth;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        _Auth=FirebaseAuth.getInstance();
        dialog=new ProgressDialog(this);

        user_name=findViewById(R.id.username_txt);
        email=findViewById(R.id.email_txt);
        password=findViewById(R.id.password_txt);
        confirm_password=findViewById(R.id.pass_confirm_txt);
        sign_up_btn=findViewById(R.id.sign_up_btn);


                sign_up_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String user_name_txt=user_name.getText().toString().trim();
                        String email_txt=email.getText().toString().trim();
                        String password_txt=password.getText().toString().trim();
                        String confirm_password_txt=confirm_password.getText().toString().trim();


                        if(TextUtils.isEmpty(user_name_txt)){
                            user_name.setError("Required field..");
                            return;
                        }
                        if(TextUtils.isEmpty(email_txt)){
                            email.setError("Required field..");
                            return;
                        }
                        if(TextUtils.isEmpty(password_txt)){
                            password.setError("Required field..");
                            return;
                        }
                        if(TextUtils.isEmpty(confirm_password_txt)){
                            confirm_password.setError("Required field..");
                            return;
                        }
                        if(!password_txt.equals(confirm_password_txt)){
                            confirm_password.setError("not match");
                            return;
                        }

                        dialog.setMessage("Processing...");
                        dialog.show();

                        _Auth.createUserWithEmailAndPassword(email_txt,password_txt).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Log.d("Successful", "onComplete: sucsess");
                                    Toast.makeText(getApplicationContext(),"Successful sign up",Toast.LENGTH_LONG);
                                    startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                                    dialog.dismiss();
                                }
                                else{
                                    Toast.makeText(getApplicationContext(),"Failed sign up...",Toast.LENGTH_LONG);
                                    Log.d("fail", "onComplete: fail");
                                    dialog.dismiss();


                                }
                            }
                        });
                    }
                });
   }
}
