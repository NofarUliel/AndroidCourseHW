package com.example.addit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private EditText email;
    private EditText password;
    private Button log_in_btn;
    private Button sign_up_btn;
    private FirebaseAuth _Auth;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _Auth=FirebaseAuth.getInstance();
        if(_Auth!=null){
            startActivity(new Intent(getApplicationContext(),HomeActivity.class));
        }
        dialog=new ProgressDialog(this);

        email=findViewById(R.id.email_txt);
        password=findViewById(R.id.password_txt);
        sign_up_btn=findViewById(R.id.sign_up_btn);
        log_in_btn=findViewById(R.id.log_in_btn);

       log_in_btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String email_txt=email.getText().toString().trim();
               String password_txt=password.getText().toString().trim();

               if(TextUtils.isEmpty(email_txt)){
                   email.setError("Required field..");
                   return;
               }
               if(TextUtils.isEmpty(password_txt)){
                   password.setError("Required field..");
                   return;
               }
               dialog.setMessage("Processing...");
               dialog.show();

               _Auth.signInWithEmailAndPassword(email_txt,password_txt).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                   @Override
                   public void onComplete(@NonNull Task<AuthResult> task) {
                       if(task.isSuccessful()){
                           Log.d("Successful", "onComplete: sucsess");
                           Toast.makeText(getApplicationContext(),"Successful log in",Toast.LENGTH_LONG);
                           startActivity(new Intent(getApplicationContext(),HomeActivity.class));
                           dialog.dismiss();
                       }
                       else{
                           Log.d("fail", "onComplete: fail");
                           Toast.makeText(getApplicationContext(),"Failed log in",Toast.LENGTH_LONG);
                           dialog.dismiss();


                       }
                   }
               });
           }
       });

        sign_up_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SignUpActivity.class));
            }
        });
    }
}
