package com.example.addit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.addit.Model.ShoppingListData;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.util.Date;

public class HomeActivity extends AppCompatActivity {
   private ImageButton plus_btn;
   private DatabaseReference DB;
   private FirebaseAuth auth;
   private RecyclerView recyclerView;
   private  String userID;
   private ShoppingListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        auth=FirebaseAuth.getInstance();
        FirebaseUser this_user=auth.getCurrentUser();
         userID=this_user.getUid();

        DB= FirebaseDatabase.getInstance().getReference().child("Shopping List").child(userID);
        DB.keepSynced(true);


        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager=new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);


        FirebaseRecyclerOptions<ShoppingListData> options =
                new FirebaseRecyclerOptions.Builder<ShoppingListData>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Shopping List").child(userID), ShoppingListData.class)
                        .build();

        adapter = new ShoppingListAdapter(options);
        recyclerView.setAdapter(adapter);



        plus_btn = findViewById(R.id.add_list_btn);
        plus_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder myDialog=new AlertDialog.Builder(HomeActivity.this);
                LayoutInflater inflater=LayoutInflater.from(HomeActivity.this);
                View myView=inflater.inflate(R.layout.input_data,null);
                final AlertDialog dialog=myDialog.create();
                dialog.setView(myView);

                final EditText list_name=myView.findViewById(R.id.list_name);
                final EditText note=myView.findViewById(R.id.note);
                Button add_btn=myView.findViewById(R.id.add_btn);
                Button cancel_btn=myView.findViewById(R.id.cancel_btn);

                add_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String list_name_txt=list_name.getText().toString().trim();
                        String note_txt=note.getText().toString().trim();

                        if(TextUtils.isEmpty(list_name_txt)){
                            list_name.setError("Required Field... ");
                            return;
                        }
                        if(TextUtils.isEmpty(note_txt)){
                            note.setError("Required Field... ");
                            return;
                        }

                        String id=DB.push().getKey();
                        String date= DateFormat.getDateInstance().format(new Date());
                        ShoppingListData listData=new ShoppingListData(id,list_name_txt,note_txt,date);
                        DB.child(id).setValue(listData);

                        dialog.dismiss();
                    }
                });

                cancel_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });



                dialog.show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();

    }


}
