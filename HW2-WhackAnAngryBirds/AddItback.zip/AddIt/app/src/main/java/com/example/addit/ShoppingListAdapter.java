package com.example.addit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addit.Model.ShoppingListData;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class ShoppingListAdapter extends FirebaseRecyclerAdapter<ShoppingListData, ShoppingListAdapter.ShoppingListHolder> {


    public ShoppingListAdapter(@NonNull FirebaseRecyclerOptions<ShoppingListData> options) {
        super(options);
    }


    @Override
    protected void onBindViewHolder(@NonNull ShoppingListHolder shoppingListHolder, int i, @NonNull ShoppingListData shoppingListData) {
        shoppingListHolder.list_name.setText(shoppingListData.getName());
        shoppingListHolder.list_note.setText(shoppingListData.getNote());

    }

    @NonNull
    @Override
    public ShoppingListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list, parent, false);
        return new ShoppingListHolder(view);
    }





    public class ShoppingListHolder extends RecyclerView.ViewHolder {

        TextView list_name, list_note;

        public ShoppingListHolder(@NonNull View itemView) {

            super(itemView);
            list_name = itemView.findViewById(R.id.name);
            list_note = itemView.findViewById(R.id.note);
        }

    }
}
